@echo off
title Smart Attendance Pro - AI Engine Stopper
color 0C
echo ===================================================
echo    Smart Attendance Pro - AI Engine Stopper
echo ===================================================
echo.
echo Menghentikan semua kontainer AI Face Recognition...
echo.
docker-compose down
echo.
echo ===================================================
echo   AI Face Recognition Engine berhasil dimatikan.
echo ===================================================
echo.
pause
