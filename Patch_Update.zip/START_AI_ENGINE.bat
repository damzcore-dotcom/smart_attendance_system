@echo off
title Smart Attendance Pro - AI Engine Launcher
color 0E
echo ===================================================
echo    Smart Attendance Pro - AI Engine Launcher
echo ===================================================
echo.

docker -v >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERROR] Docker tidak terdeteksi!
  echo         Silakan instal Docker Desktop terlebih dahulu untuk menggunakan AI.
  echo         Unduh: https://www.docker.com/products/docker-desktop/
  echo.
  pause
  exit /b
)

echo [✓] Docker terdeteksi. Menyalakan AI Face Recognition Engine...
echo     (Redis, MinIO, dan AI Engine akan berjalan di latar belakang)
echo.

docker-compose up -d --build ai-engine redis minio

echo.
echo ===================================================
echo   AI Face Recognition Engine berhasil dinyalakan!
echo   - AI Service   : http://localhost:8001/health
echo   - MinIO Console: http://localhost:9001 (user: minioadmin / pass: minioadmin123)
echo ===================================================
echo.
pause
